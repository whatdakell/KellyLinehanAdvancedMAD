package com.example.keli5466.finalkl;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;



public class MainActivity extends  AppCompatActivity implements UniverseList.UniverseListListener, HeroDetail.ButtonClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override public void itemClicked(long id){
        View fragmentContainer = findViewById(R.id.fragment_container);
        if (fragmentContainer != null) {

            HeroDetail frag = new HeroDetail();
            FragmentTransaction ft = getFragmentManager().beginTransaction();
            frag.setUniverse(id);
            ft.replace(R.id.fragment_container, frag);
            ft.addToBackStack(null);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.commit();
        }else{
            Intent intent = new Intent(this, BulbActivity.class);
            intent.putExtra("id", (int) id);
            startActivity(intent);
        }
    }

    @Override public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0 ){
            getFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    @Override public void addheroclicked(View view){
        HeroDetail fragment = (HeroDetail)getFragmentManager().findFragmentById(R.id.fragment_container);
        fragment.addhero();
    }
}

//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener(){
//            public void onItemClick(AdapterView<?> listView, View view, int position, long id){
//                String bulbtype = (String) listView.getItemAtPosition(position);
//
//                //create new intent
//                Intent intent = new Intent(MainActivity.this, Cat.class);
//
//                //add bulbtype to intent
//                intent.putExtra("bulbtype", bulbtype);
//
//                //start intent
//                startActivity(intent);
//            }
//        };
//        //get the list view
//        ListView listview = (ListView) findViewById(R.id.listView);
//
//        //add listener to the list view
//        listview.setOnItemClickListener(itemClickListener);
//    }
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        Intent intent = new Intent(MainActivity.this , Menu.class);
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return super.onCreateOptionsMenu(menu);
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        //get the ID of the item on the action bar that was clicked
//        switch (item.getItemId()){
//            case R.id.create_order:
//                //start order activity
//                Intent intent = new Intent(this, OrderActivity.class);
//                startActivity(intent);
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }
//}
//
