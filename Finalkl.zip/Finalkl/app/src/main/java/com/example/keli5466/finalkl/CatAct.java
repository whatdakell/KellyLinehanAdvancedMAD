package com.example.keli5466.finalkl;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by keli5466 on 4/28/16.
 */

public class CatAct {
    private String name;
    private int imageResourceID;
    private String universe;
    private ArrayList<String> superheroes = new ArrayList<>();


    private CatAct(String univ, ArrayList<String> cardio){
        this.universe = univ;
        this.superheroes = new ArrayList<String>(cardio);
    }
    private CatAct(String newname, int newID){
        this.name = newname;
        this.imageResourceID =newID;
    }
    public static final CatAct[] cardio = {
            new CatAct("Cardio", new ArrayList<String>()),
            new CatAct("Strengh", new ArrayList<String>()),
            new CatAct("Flexability", new ArrayList<String>())
    };


    //    public static final  CatAct [] cardio = {
//            new CatAct ("Cycling", R.drawable.cardio),
//            new CatAct ("Running", R.drawable.cardio),
//    };
//    public static final  CatAct [] strength = {
//            new CatAct ("Yoga", R.drawable.strength),
//            new CatAct ("Weight Train", R.drawable.strength),
//    };
//    public static final  CatAct [] flexibility = {
//            new CatAct ("Cycling", R.drawable.flexibility),
//            new CatAct ("Running", R.drawable.flexibility),
//    };

    public String getUniverse(){
        return universe;
    }

    public ArrayList<String> getSuperheroes(){
        return superheroes;
    }

    public String toString(){
        return this.universe;
    }
    public String getName(){
        return name;
    }
    public int getImageResourceID(){
        return imageResourceID;
    }
//    public String toString(){
//        return this.name;
//    }

    public void storeHeroes(Context context, long universeId){
        SharedPreferences sharedPrefs = context.getSharedPreferences("Superheroes", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPrefs.edit();
        Set<String> set = new HashSet<String>();
        set.addAll(cardio[(int) universeId].getSuperheroes());
        editor.putStringSet(cardio[(int) universeId].getUniverse(), set);
        editor.commit();
    }

    public void loadHeroes(Context context, int universeId){

        SharedPreferences sharedPrefs = context.getSharedPreferences("sdfgsfds", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPrefs.edit();
        Set<String> set =sharedPrefs.getStringSet(cardio[universeId].getUniverse(), null);
        if (set != null){
            CatAct.cardio[universeId].superheroes.addAll(set);
        }

        else {
            switch (universeId) {
                case 0:
                    CatAct.cardio[0].superheroes.addAll(Arrays.asList("Running", "Cycling"));
                    break;
                case 1:
                    CatAct.cardio[1].superheroes.addAll(Arrays.asList("Yoga", "Weights"));
                    break;
                case 2:
                    CatAct.cardio[2].superheroes.addAll(Arrays.asList("strech", "Yoga"));
                    break;

                default:
                    break;
            }
        }
    }
}