package com.example.keli5466.lab9;
import android.app.Dialog;
import android.app.ListActivity;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Button;
import android.view.View.OnClickListener;
import java.util.ArrayList;
import android.widget.EditText;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;


public class BulbCa extends ListActivity {

    private String bulbtype;
    ArrayList<String> list = new ArrayList<String>();
    ArrayAdapter<Bulb> listAdapter;
//    private ButtonClickListener listener;

    /** Declaring an ArrayAdapter to set items to ListView */
//    ArrayAdapter<String> listAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bulb_ca);
        Intent i = getIntent();
        bulbtype = i.getStringExtra("bulbtype");

        //get the list view

//        addButton.setOnClickLitener(this);
        final ListView listBulbs = getListView();

        //define an array adapter

        final ArrayAdapter<Bulb> listAdapter;


        //initialize the array adapter with the right list of bulbs
        switch (bulbtype){
            case "Cakes":
                listAdapter = new ArrayAdapter<Bulb>(this, android.R.layout.simple_list_item_1, Bulb.cakes);
                break;
            case "Cookies":
                listAdapter = new ArrayAdapter<Bulb>(this, android.R.layout.simple_list_item_1, Bulb.cookies);
                break;
            case "Pies":
                listAdapter = new ArrayAdapter<Bulb>(this, android.R.layout.simple_list_item_1, Bulb.pies);
                break;
            default: listAdapter = new ArrayAdapter<Bulb>(this, android.R.layout.simple_list_item_1, Bulb.cakes);
        }

        Button btn = (Button) findViewById(R.id.TestButton);
        final EditText d = (EditText) findViewById(R.id.txtItem);
        //set the array adapter on the list view
        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                list.add(d.getText().toString());
                listAdapter.setNotifyOnChange(true);
                listBulbs.setAdapter(listAdapter);
            }
        });
//
//        OnClickListener listener = new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                EditText edit = (EditText) findViewById(R.id.txtItem);
//                list.add(edit.getText().toString());
//                edit.setText("");
//                listAdapter.notifyDataSetChanged();
//            }
//        };

        /** Setting the event listener for the add button */
//        btn.setOnClickListener(listener);

        listBulbs.setAdapter(listAdapter);

        /** Setting the adapter to the ListView */


    }

    @Override
    public void onListItemClick(ListView listView, View view, int position, long id){
        Intent intent = new Intent(BulbCa.this, BulbAct.class);
        intent.putExtra("bulbid", (int) id);
        intent.putExtra("bulbtype", bulbtype);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        //inflate menu to add items to the action bar
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //get the ID of the item on the action bar that was clicked
        switch (item.getItemId()){
            case R.id.create_order:
                //start order activity
                Intent intent = new Intent(this, order.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
