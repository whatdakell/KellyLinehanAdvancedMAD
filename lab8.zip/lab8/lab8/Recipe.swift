//
//  Recipe.swift
//  recipes
//
//  Created by Kelly Linehan on 4/30/16.
//  Copyright © 2016 Kelly Linehan. All rights reserved.
//

import Foundation

class Recipe {
    var name: String
    var url: String
    
    init(newname: String, newurl: String){
        name = newname
        url = newurl
    }
}
